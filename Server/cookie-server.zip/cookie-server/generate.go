package main

//go:generate go run github.com/ogen-go/ogen/cmd/ogen@latest --target internal/server --clean openapi.yaml
